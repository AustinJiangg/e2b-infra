from typing import Dict, List, Optional

import httpcore
import httpx
from e2b.connection_config import ConnectionConfig
from e2b.gsd.api import (
    GSD_API_HEALTH_ROUTE,
    checkpointd_headers,
    handle_checkpoint_rpc_exception,
    handle_gsd_api_exception,
)
from e2b.gsd.checkpoint import checkpoint_connect, checkpoint_pb2
from e2b.sandbox.checkpoint.types import (
    CheckpointInfo,
    process_trees_of,
    timings_dict,
)


class Checkpoint:
    """
    Module for checkpointing and restoring sandbox state via GSD.
    """

    def __init__(
        self,
        checkpointd_api_url: str,
        connection_config: ConnectionConfig,
        pool: httpcore.ConnectionPool,
        envd_api: httpx.Client,
        envd_access_token: Optional[str] = None,
        traffic_access_token: Optional[str] = None,
    ) -> None:
        self._connection_config = connection_config
        self.last_timings: Optional[Dict[str, float]] = None
        """GSD's per-stage timings (milliseconds) of the most recent successful
        ``create()`` or ``restore()`` made through this object, ``None`` before
        the first one or when GSD does not send timings. See
        :attr:`CheckpointInfo.timings` for the create stages; restore reports
        ``total_ms``, ``find_pids_ms``, ``precheck_ms``, ``kill_ms``,
        ``overlay_restore_ms`` and ``criu_restore_ms``."""
        headers = checkpointd_headers(
            connection_config, envd_access_token, traffic_access_token
        )
        self._rpc = checkpoint_connect.CheckpointClient(
            checkpointd_api_url,
            pool=pool,
            json=True,
            headers=headers,
        )
        # /health goes through the sandbox's envd HTTP client instead of a client of
        # our own: that client is owned (and would be closed) by the Sandbox and sits
        # on the shared transport, so nothing is left open per Checkpoint object. The
        # absolute URL and per-request headers take precedence over its base URL and
        # envd headers.
        self._http = envd_api
        self._health_url = checkpointd_api_url.rstrip("/") + GSD_API_HEALTH_ROUTE
        self._headers = headers

    def is_running(self, request_timeout: Optional[float] = None) -> bool:
        """
        Check if GSD (checkpointd) is running in the sandbox.

        :param request_timeout: Timeout for the request in **seconds**

        :return: ``True`` if GSD is running, ``False`` otherwise
        """
        try:
            r = self._http.get(
                self._health_url,
                headers=self._headers,
                timeout=self._connection_config.get_request_timeout(request_timeout),
            )

            if r.status_code == 502:
                return False

            err = handle_gsd_api_exception(r)

            if err:
                raise err

        except httpx.TimeoutException:
            raise

        return True

    def create(
        self,
        name: Optional[str] = None,
        request_timeout: Optional[float] = None,
    ) -> CheckpointInfo:
        """
        Create a checkpoint of the sandbox's current state.

        :param name: Optional name for the checkpoint
        :param request_timeout: Timeout for the request in **seconds**

        :return: CheckpointInfo with the checkpoint ID and metadata
        """
        try:
            req = checkpoint_pb2.CreateCheckpointRequest()
            if name is not None:
                req.name = name

            res = self._rpc.create_checkpoint(
                req,
                request_timeout=self._connection_config.get_request_timeout(
                    request_timeout
                ),
            )

            timings = timings_dict(res.timings) if res.HasField("timings") else None
            self.last_timings = timings
            return CheckpointInfo(
                checkpoint_id=res.checkpoint_id,
                name=name,
                created_at=res.created_at or None,
                timings=timings,
                has_process_image=res.has_process_image,
                parent_checkpoint_id=res.parent_checkpoint_id or None,
                image_bytes=res.image_bytes,
                clear_refs_failed=res.clear_refs_failed,
                process_trees=process_trees_of(res),
            )
        except Exception as e:
            raise handle_checkpoint_rpc_exception(e)

    def restore(
        self,
        checkpoint_id: str,
        request_timeout: Optional[float] = None,
    ) -> bool:
        """
        Restore the sandbox to a previously created checkpoint.

        :param checkpoint_id: ID of the checkpoint to restore
        :param request_timeout: Timeout for the request in **seconds**

        :return: True if the restore was successful
        """
        try:
            res = self._rpc.restore_checkpoint(
                checkpoint_pb2.RestoreCheckpointRequest(
                    checkpoint_id=checkpoint_id,
                ),
                request_timeout=self._connection_config.get_request_timeout(
                    request_timeout
                ),
            )
            self.last_timings = (
                timings_dict(res.timings) if res.HasField("timings") else None
            )
            return res.success
        except Exception as e:
            raise handle_checkpoint_rpc_exception(e)

    def list(
        self,
        request_timeout: Optional[float] = None,
    ) -> List[CheckpointInfo]:
        """
        List all checkpoints in the sandbox.

        :param request_timeout: Timeout for the request in **seconds**

        :return: List of CheckpointInfo objects
        """
        try:
            res = self._rpc.list_checkpoints(
                checkpoint_pb2.ListCheckpointsRequest(),
                request_timeout=self._connection_config.get_request_timeout(
                    request_timeout
                ),
            )

            result = []
            for cp in res.checkpoints:
                result.append(
                    CheckpointInfo(
                        checkpoint_id=cp.checkpoint_id,
                        name=cp.name if cp.HasField("name") else None,
                        created_at=cp.created_at,
                        has_process_image=cp.has_process_image,
                        parent_checkpoint_id=cp.parent_checkpoint_id or None,
                        image_bytes=cp.image_bytes,
                        process_trees=process_trees_of(cp),
                    )
                )
            return result
        except Exception as e:
            raise handle_checkpoint_rpc_exception(e)

    def delete(
        self,
        checkpoint_id: str,
        request_timeout: Optional[float] = None,
    ) -> bool:
        """
        Delete a checkpoint.

        :param checkpoint_id: ID of the checkpoint to delete
        :param request_timeout: Timeout for the request in **seconds**

        :return: True if the deletion was successful
        """
        try:
            res = self._rpc.delete_checkpoint(
                checkpoint_pb2.DeleteCheckpointRequest(
                    checkpoint_id=checkpoint_id,
                ),
                request_timeout=self._connection_config.get_request_timeout(
                    request_timeout
                ),
            )
            return res.success
        except Exception as e:
            raise handle_checkpoint_rpc_exception(e)