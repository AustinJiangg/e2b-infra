from typing import Dict, Optional


class CheckpointInfo:
    """
    Metadata of a checkpoint, returned by ``create()`` and ``list()``.

    Fields that an older GSD does not send keep their default (``None`` for
    ``timings``, ``False``/``0``/``None`` for the rest).
    """

    def __init__(
        self,
        checkpoint_id: str,
        name: Optional[str] = None,
        created_at: Optional[int] = None,
        timings: Optional[Dict[str, float]] = None,
        has_process_image: bool = False,
        parent_checkpoint_id: Optional[str] = None,
        image_bytes: int = 0,
        clear_refs_failed: int = 0,
        process_trees: int = 0,
    ):
        self.checkpoint_id = checkpoint_id
        """Checkpoint ID."""
        self.name = name
        """Name given at creation, if any."""
        self.created_at = created_at
        """Creation time, Unix time in nanoseconds (GSD's clock inside the sandbox)."""
        self.timings = timings
        """Only from ``create()``: how long each stage took inside GSD, in
        milliseconds, keyed by stage (``total_ms``, ``find_pids_ms``,
        ``precheck_ms``, ``criu_dump_ms``, ``overlay_sink_ms``, ``stopped_ms``).
        Stages that did not run are left out. With several process trees
        ``criu_dump_ms`` is the sum over all trees."""
        self.has_process_image = has_process_image
        """Whether user processes were dumped. ``False`` means the checkpoint only
        holds the filesystem; restoring it kills the current user processes and
        starts none."""
        self.process_trees = process_trees
        """Number of user process trees in the checkpoint (each background
        command is one tree); ``0`` when ``has_process_image`` is ``False``.
        Every tree is dumped and restored by its own CRIU run. A GSD from before
        multi-tree support does not send it; it handled exactly one tree, so the
        SDK reports ``1`` when there is a process image."""
        self.parent_checkpoint_id = parent_checkpoint_id
        """The checkpoint whose CRIU images this one is an increment of; ``None``
        when every process tree was dumped in full or there are no processes.
        Set as soon as one tree is incremental. The parent may already be deleted
        (its images are kept as long as this checkpoint needs them)."""
        self.image_bytes = image_bytes
        """Size of this checkpoint's own CRIU images in bytes (parents not included)."""
        self.clear_refs_failed = clear_refs_failed
        """Only from ``create()``: processes whose soft-dirty bits could not be
        reset after the checkpoint. Non-zero means the next checkpoint of those
        processes will be larger than needed; see the GSD log."""

    def __repr__(self) -> str:
        return f"CheckpointInfo(id={self.checkpoint_id}, name={self.name})"


def timings_dict(timings) -> Optional[Dict[str, float]]:
    """Convert a GSD ``Timings`` message into a dict of the stages that ran.

    :param timings: The ``Timings`` field of a GSD response, or ``None``.
    :return: ``{stage: milliseconds}``, or ``None`` if GSD sent no timings.
    """
    if timings is None:
        return None
    # Only the stages: Timings also carries process_trees (a count, not a duration),
    # which is reported as CheckpointInfo.process_trees.
    return {
        field.name: value
        for field, value in timings.ListFields()
        if field.name.endswith("_ms")
    }


def process_trees_of(msg) -> int:
    """Number of process trees of a create response or list entry.

    A GSD from before multi-tree support does not send ``process_trees``; it
    handled exactly one tree, so a process image means one tree.
    """
    return msg.process_trees or (1 if msg.has_process_image else 0)
