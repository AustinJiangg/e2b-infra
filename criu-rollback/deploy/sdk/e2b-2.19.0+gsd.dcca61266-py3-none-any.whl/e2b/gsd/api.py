import httpx
import json

from typing import Any, Callable, Dict, Optional

from e2b_connect.client import Code

from e2b.envd.rpc import handle_rpc_exception
from e2b.exceptions import (
    CheckpointRestoreException,
    SandboxException,
    NotFoundException,
    NotEnoughSpaceException,
    AuthenticationException,
    InvalidArgumentException,
    TimeoutException,
    format_sandbox_timeout_exception,
)


GSD_API_HEALTH_ROUTE = "/health"

ACCESS_TOKEN_HEADER = "X-Access-Token"

TRAFFIC_ACCESS_TOKEN_HEADER = "e2b-traffic-access-token"


def checkpointd_headers(
    connection_config: Any,
    envd_access_token: Optional[str] = None,
    traffic_access_token: Optional[str] = None,
) -> Dict[str, str]:
    """Headers for requests to GSD.

    GSD checks ``X-Access-Token`` against the sandbox's access token hash in MMDS,
    the same token envd uses. For secure sandboxes the token usually already arrives
    via the connection config's extra sandbox headers; it is set here explicitly so
    GSD gets it no matter how the connection config was built.

    A sandbox created with ``allow_public_traffic=False`` has a traffic access token:
    the host proxy answers 403 on every port but envd's unless the request carries it
    in ``e2b-traffic-access-token``, so GSD is unreachable without that header.

    :param connection_config: The sandbox's ``ConnectionConfig``.
    :param envd_access_token: The sandbox's envd access token, if any.
    :param traffic_access_token: The sandbox's traffic access token, if any.
    """
    headers = dict(connection_config.checkpointd_headers)
    if isinstance(envd_access_token, str) and envd_access_token:
        headers[ACCESS_TOKEN_HEADER] = envd_access_token
    if isinstance(traffic_access_token, str) and traffic_access_token:
        headers[TRAFFIC_ACCESS_TOKEN_HEADER] = traffic_access_token
    return headers


# Error mapping for the checkpoint RPCs. envd's default map is written for envd: it turns
# resource_exhausted into RateLimitException("... Rate limit exceeded") and
# deadline_exceeded into a hint about the SDK's 'timeout' option, both wrong for GSD.
# GSD uses these codes as follows (packages/gsd, checkpoint service):
#   resource_exhausted   the checkpoint does not fit: estimated CRIU images exceed the
#                        snapshot store or MemAvailable, or the overlay layer stack
#                        would exceed the kernel's option length; nothing was changed
#   failed_precondition  the request was refused: user process trees that share a pipe or
#                        socket, images of the checkpoint unusable, or GSD degraded (see
#                        its /health)
#   data_loss            restore failed after the user processes were killed
#   deadline_exceeded    create: CRIU dump exceeded GSD's own time limit; the images were
#                        discarded and the processes resumed
# Codes not listed here (not_found, unauthenticated, internal, ...) keep envd's mapping.
CHECKPOINT_RPC_ERROR_MAP: dict[Code, Callable[[str], Exception]] = {
    Code.resource_exhausted: lambda message: NotEnoughSpaceException(
        f"{message}: the checkpoint does not fit; delete some checkpoints or free "
        "memory in the sandbox and try again. Nothing was changed."
    ),
    Code.failed_precondition: lambda message: SandboxException(
        f"Checkpoint request refused by GSD (failed_precondition): {message}"
    ),
    Code.data_loss: lambda message: CheckpointRestoreException(
        f"{message}. The sandbox's processes were killed before the failure; "
        "restore a checkpoint to bring the sandbox back to a consistent state "
        "(creating checkpoints is refused until then)."
    ),
    Code.deadline_exceeded: lambda message: TimeoutException(
        f"{message}: CRIU did not finish within GSD's time limit in the sandbox "
        "(not the SDK's request_timeout). The checkpoint was not created and the "
        "sandbox's processes were resumed."
    ),
}


def handle_checkpoint_rpc_exception(e: Exception) -> Exception:
    """Map an exception from a GSD checkpoint RPC with :data:`CHECKPOINT_RPC_ERROR_MAP`
    (falling back to envd's defaults for other codes)."""
    return handle_rpc_exception(e, CHECKPOINT_RPC_ERROR_MAP)


_DEFAULT_GSD_API_ERROR_MAP: dict[int, Callable[[str], Exception]] = {
    400: InvalidArgumentException,
    401: AuthenticationException,
    404: NotFoundException,
    502: format_sandbox_timeout_exception,
}


def get_message(e: httpx.Response) -> str:
    try:
        message = e.json().get("message", e.text)
    except json.JSONDecodeError:
        message = e.text

    return message


def handle_gsd_api_exception(
    res: httpx.Response,
    error_map: Optional[dict[int, Callable[[str], Exception]]] = None,
):
    """Handle errors from GSD API responses by mapping HTTP status codes to specific exception types.

    :param res: The HTTP response.
    :param error_map: Optional map of HTTP status codes to exception factories that override the defaults.
    :return: The corresponding exception, or ``None`` if the response is successful.
    """
    if res.is_success:
        return

    res.read()

    return format_gsd_api_exception(res.status_code, get_message(res), error_map)


async def ahandle_gsd_api_exception(
    res: httpx.Response,
    error_map: Optional[dict[int, Callable[[str], Exception]]] = None,
):
    """Async version of :func:`handle_gsd_api_exception`."""
    if res.is_success:
        return

    await res.aread()

    return format_gsd_api_exception(res.status_code, get_message(res), error_map)


def format_gsd_api_exception(
    status_code: int,
    message: str,
    error_map: Optional[dict[int, Callable[[str], Exception]]] = None,
):
    """Map an HTTP status code and message to the appropriate exception.

    :param status_code: The HTTP status code.
    :param message: The error message from the response body.
    :param error_map: Optional map of HTTP status codes to exception factories that override the defaults.
    :return: The corresponding exception.
    """
    if error_map and status_code in error_map:
        return error_map[status_code](message)

    if status_code in _DEFAULT_GSD_API_ERROR_MAP:
        return _DEFAULT_GSD_API_ERROR_MAP[status_code](message)

    return SandboxException(f"GSD error {status_code}: {message}")