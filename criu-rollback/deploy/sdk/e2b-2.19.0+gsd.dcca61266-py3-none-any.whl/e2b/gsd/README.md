# GSD — Checkpoint/Restore SDK
SDK 内部通过 Connect-RPC 协议与 VM 内的 GSD 守护进程通信，提供沙箱状态的快照与恢复能力。
## 设计要点
- **独立于 envd**：GSD 使用独立端口(49984)和独立 proto，envd 代码无任何修改
- **checkpoint 不持久化**：数据存储在 VM 内，VM 销毁后丢失（不同于 E2B snapshot API）
## SDK 模块结构
```
e2b/
├── gsd/                              # 底层通信层
│   ├── api.py                        # HTTP 错误映射 + /health 路由常量
│   └── checkpoint/
│       ├── checkpoint_pb2.py         # Protobuf 消息定义（生成）
│       ├── checkpoint_pb2.pyi        # Protobuf 类型桩（生成）
│       ├── checkpoint_connect.py     # Connect-RPC 客户端（生成）
├── sandbox/
│   └── checkpoint/
│       └── types.py                  # 用户面向类型：CheckpointInfo
├── sandbox_sync/
│   └── checkpoint.py                 # 同步 Checkpoint 类
├── sandbox_async/
│   └── checkpoint.py                 # 异步 AsyncCheckpoint 类
├── connection_config.py              # checkpointd_port=49984、get_checkpointd_url()、checkpointd_headers
├── sandbox/main.py                   # SandboxBase 增加 checkpointd_api_url 属性
```
各层职责：
| 层 | 文件 | 职责 |
|---|---|---|
| 通信层 | `gsd/checkpoint/` | protobuf 编解码 + Connect-RPC HTTP 通信 |
| 错误处理 | `gsd/api.py` | checkpoint RPC 的错误码映射（`CHECKPOINT_RPC_ERROR_MAP`）；`/health` 端点的 HTTP 状态码→E2B 异常映射 |
| 用户面向类型 | `sandbox/checkpoint/types.py` | `CheckpointInfo` Python 类 |
| 业务方法 | `sandbox_sync/checkpoint.py` / `sandbox_async/checkpoint.py` | `create()`/`restore()`/`list()`/`delete()`/`is_running()` |
通信层与 envd 共用：`e2b.envd.rpc.handle_rpc_exception()`，checkpoint 方法在它上面覆盖几个 GSD 自己含义的错误码（见"错误处理"）；`is_running()` 的 HTTP 请求走 Sandbox 的 envd HTTP 客户端（同一个共享 transport，不另建客户端），用绝对 URL 和 gsd 的请求头。

### 鉴权与地址

- 请求头来自 `e2b.gsd.api.checkpointd_headers()`：`ConnectionConfig.checkpointd_headers`（沙箱请求头，`E2b-Sandbox-Port` 改成 49984）加上 `X-Access-Token`（沙箱的 envd access token）。沙箱带入口流量令牌（`allow_public_traffic=False`）时再加 `e2b-traffic-access-token`，否则宿主代理对 49984 端口一律回 403。GSD 只校验 `X-Access-Token`；以前固定发的 `Authorization: Basic root:` 已删除。
- GSD 的地址 `get_checkpointd_url()`：显式的 `checkpointd_url`（构造参数，或环境变量 `E2B_CHECKPOINTD_URL`）优先；否则有 `sandbox_url`（`E2B_SANDBOX_URL`）时原样用它（按 `E2b-Sandbox-Id`/`E2b-Sandbox-Port` 头路由的代理，端口头已经是 49984）；都没有时是 `http://49984-<sandbox_id>.<domain>`。`sandbox_url` 直连 envd 的场合要另设 `checkpointd_url`。
## API 参考
### CheckpointInfo
checkpoint 的元数据对象，由 `create()` 和 `list()` 返回。
| 字段 | 类型 | 说明 |
|---|---|---|
| `checkpoint_id` | `str` | checkpoint ID |
| `name` | `Optional[str]` | 创建时指定的名称 |
| `created_at` | `Optional[int]` | 创建时间，Unix 纳秒（沙箱内 GSD 的时钟） |
| `has_process_image` | `bool` | 是否 dump 了用户进程；`False` 表示只有文件系统，restore 它会杀掉当前用户进程且不恢复任何进程 |
| `process_trees` | `int` | checkpoint 里用户进程树的数量（每个后台命令是一棵）；`has_process_image` 为 `False` 时是 0。不支持多树的旧版 GSD 不发这个字段，有进程镜像时 SDK 报 1 |
| `parent_checkpoint_id` | `Optional[str]` | 增量 dump 的父 checkpoint；所有树都是全量或没有进程时为 `None`，只要有一棵树是增量就有值。父节点可能已被删除（镜像保留到子节点删光） |
| `image_bytes` | `int` | 本 checkpoint 自己的 CRIU 镜像大小（字节，不含父镜像） |
| `timings` | `Optional[Dict[str, float]]` | 仅 `create()`：GSD 内各阶段耗时（毫秒），键为 `total_ms`、`find_pids_ms`、`precheck_ms`、`criu_dump_ms`、`overlay_sink_ms`、`stopped_ms`，没跑的阶段不出现；多棵树时 `criu_dump_ms` 是各棵树之和 |
| `clear_refs_failed` | `int` | 仅 `create()`：checkpoint 后没能重置 soft-dirty 的进程数；非 0 表示下一次增量会偏大，看 GSD 日志 |

旧版 GSD 不发的字段取默认值（`timings`、`created_at`、`parent_checkpoint_id` 为 `None`，其余为 `False`/`0`；`process_trees` 见上）。

`sandbox.checkpoint.last_timings`：最近一次成功的 `create()` 或 `restore()` 的各阶段耗时（`restore()` 仍返回 `bool`，它的耗时只在这里），restore 的键为 `total_ms`、`find_pids_ms`、`precheck_ms`、`kill_ms`、`overlay_restore_ms`、`criu_restore_ms`（多棵树时是各棵树之和）。`timings`/`last_timings` 里只有以 `_ms` 结尾的阶段耗时；GSD 的 `Timings.process_trees` 是个数不是耗时，不放进这两个字典。

### 多棵用户进程树

沙箱里可以同时有多棵用户进程树：每个 `commands.run(..., background=True)` 是一棵。`create()` 保存
当时的全部树，`restore()` 把目标 checkpoint 里的全部树恢复出来（当前的用户进程先全部杀掉），接口
不变，`CheckpointInfo.process_trees` 是树的数量。需要知道的限制：

- **各棵树单独保存、单独恢复**。树之间通过管道或 socket 相连时恢复不回去：一条管道的读端和写端分在
  两棵树里、或两棵树持有同一个 socket 时，`create()` 抛 `SandboxException`（`failed_precondition`，
  信息里写明是哪两棵树、哪条管道/哪个 socket），什么都没改；两棵树之间的 unix socket 连接由 CRIU
  在 dump 时报错，`create()` 抛 `SandboxException`（`internal`，带 CRIU 日志尾部）。要一起保存的
  互相连接的进程，用同一个命令起成一棵树（例如 `sh -c 'producer | consumer'`）。
- **树之间不是同一瞬间**：各棵树依次冻住，先后差一棵树的 dump 时间（几十毫秒量级），全部冻住之后
  才保存文件系统。互不通信的后台命令不受影响。
- **restore 中途失败**（`CheckpointRestoreException`）时，错误信息写明哪几棵树已经恢复、哪棵失败、
  哪几棵没有尝试；再 restore 一次（任何一个 checkpoint）即可回到完整状态。
- restore 的耗时随树的数量线性增加。
### 方法
| 方法 | 参数 | 返回类型 | 说明 |
|---|---|---|---|
| `create(name?, request_timeout?)` | `name`: 可选名称 | `CheckpointInfo` | 创建 checkpoint |
| `restore(checkpoint_id, request_timeout?)` | `checkpoint_id`: 要恢复的 ID | `bool` | 恢复到指定 checkpoint |
| `list(request_timeout?)` | 无 | `List[CheckpointInfo]` | 列出所有 checkpoint |
| `delete(checkpoint_id, request_timeout?)` | `checkpoint_id`: 要删除的 ID | `bool` | 删除指定 checkpoint |
| `is_running(request_timeout?)` | 无 | `bool` | 检查 GSD 是否运行 |

`request_timeout` 单位为秒，不传时用 `ConnectionConfig.request_timeout`（默认 60 秒），传 `0` 表示不限时。
同步调用：`sandbox.checkpoint.create()`
异步调用：`await sandbox.checkpoint.create()`
## 使用示例
### 同步
```python
from e2b import Sandbox
sandbox = Sandbox.create()
cp = sandbox.checkpoint.create(name="step-1")
print(cp.checkpoint_id)
sandbox.commands.run("pip install numpy")
cp2 = sandbox.checkpoint.create(name="after-install")
sandbox.checkpoint.restore(cp.checkpoint_id)
checkpoints = sandbox.checkpoint.list()
sandbox.checkpoint.delete(cp2.checkpoint_id)
sandbox.checkpoint.is_running()  # True
```
### 异步
```python
from e2b import AsyncSandbox
sandbox = await AsyncSandbox.create()
cp = await sandbox.checkpoint.create(name="step-1")
await sandbox.checkpoint.restore(cp.checkpoint_id)
checkpoints = await sandbox.checkpoint.list()
await sandbox.checkpoint.delete(cp.checkpoint_id)
await sandbox.checkpoint.is_running()
```
## 错误处理
### checkpoint 方法错误
通过 `e2b.gsd.api.handle_checkpoint_rpc_exception()` 映射 Connect-RPC 错误码：它用
`CHECKPOINT_RPC_ERROR_MAP` 覆盖 GSD 自己含义的四个码，其余沿用 envd 的默认映射（envd 把
`resource_exhausted` 当成限流、把 `deadline_exceeded` 当成 SDK 的 `timeout`，对 GSD 都不对）。
| Connect Code | E2B Exception | GSD 的含义 |
|---|---|---|
| `resource_exhausted` | `NotEnoughSpaceException` | 放不下：估算的 CRIU 镜像超过 snapshot store 剩余空间或 MemAvailable，或层栈太深（选项串超过内核上限）；什么都没改 |
| `failed_precondition` | `SandboxException("Checkpoint request refused by GSD (failed_precondition): ...")` | 请求被拒：用户进程树之间共享管道或 socket、checkpoint 的镜像不可用、GSD degraded（见 `/health`）；什么都没改 |
| `data_loss` | `CheckpointRestoreException`（`SandboxException` 的子类） | restore 在杀掉进程之后失败，信息里写明文件系统处于旧状态还是目标状态（多棵树时还有哪几棵已恢复、哪棵失败）；GSD 进入 degraded、拒绝 create，直到下一次成功的 restore |
| `deadline_exceeded` | `TimeoutException` | create 的 criu dump 超过 GSD 自己的时限（每棵树 60 秒、全部树合计 180 秒，不是 SDK 的 `request_timeout`）；镜像已丢弃，进程已放开 |
| `invalid_argument` / `unauthenticated` / `not_found` | `InvalidArgumentException` / `AuthenticationException` / `NotFoundException` | |
| `unavailable` / `canceled` | 沙箱超时异常 / `TimeoutException` | |
| 其他（如 `internal`） | `SandboxException("<code>: <message>")` | |

### `is_running()` HTTP 错误
通过 `handle_gsd_api_exception()` 映射 HTTP 状态码：
| HTTP 状态码 | E2B Exception |
|---|---|
| 400 | `InvalidArgumentException` |
| 401 | `AuthenticationException` |
| 404 | `NotFoundException` |
| 502 | 沙箱超时异常（`is_running()` 内部直接返回 `False`，不抛异常） |
| 其他 | `SandboxException("GSD error {code}: {message}")` |
## 注意事项
1. **checkpoint 不持久化**：VM 销毁后所有 checkpoint 数据丢失，不同于 E2B snapshot API（持久化到存储）
2. **与 snapshot API 独立**：checkpoint 是内存级快照，snapshot 是存储级快照，两者互不影响
3. **Proto 代码生成**：`checkpoint_pb2.py`、`checkpoint_pb2.pyi`、`checkpoint_connect.py` 都是生成文件，不要手改：`make generate-gsd` 用 buf 按 `spec/gsd/buf-python.gen.yaml` 从 `spec/gsd/checkpoint/checkpoint.proto` 生成（protoc 的 python/pyi 插件加 `protoc-gen-connect-python`），再由 `scripts/fix-python-pb-gsd.sh` 改写导入路径。`spec/gsd/checkpoint/checkpoint.proto` 与 `packages/gsd/spec/checkpoint/checkpoint.proto` 要保持相同。
