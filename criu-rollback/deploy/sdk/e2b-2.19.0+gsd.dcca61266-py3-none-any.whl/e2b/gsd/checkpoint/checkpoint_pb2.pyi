from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateCheckpointRequest(_message.Message):
    __slots__ = ("name",)
    NAME_FIELD_NUMBER: _ClassVar[int]
    name: str
    def __init__(self, name: _Optional[str] = ...) -> None: ...

class Timings(_message.Message):
    __slots__ = ("total_ms", "find_pids_ms", "precheck_ms", "criu_dump_ms", "overlay_sink_ms", "stopped_ms", "kill_ms", "overlay_restore_ms", "criu_restore_ms", "process_trees")
    TOTAL_MS_FIELD_NUMBER: _ClassVar[int]
    FIND_PIDS_MS_FIELD_NUMBER: _ClassVar[int]
    PRECHECK_MS_FIELD_NUMBER: _ClassVar[int]
    CRIU_DUMP_MS_FIELD_NUMBER: _ClassVar[int]
    OVERLAY_SINK_MS_FIELD_NUMBER: _ClassVar[int]
    STOPPED_MS_FIELD_NUMBER: _ClassVar[int]
    KILL_MS_FIELD_NUMBER: _ClassVar[int]
    OVERLAY_RESTORE_MS_FIELD_NUMBER: _ClassVar[int]
    CRIU_RESTORE_MS_FIELD_NUMBER: _ClassVar[int]
    PROCESS_TREES_FIELD_NUMBER: _ClassVar[int]
    total_ms: float
    find_pids_ms: float
    precheck_ms: float
    criu_dump_ms: float
    overlay_sink_ms: float
    stopped_ms: float
    kill_ms: float
    overlay_restore_ms: float
    criu_restore_ms: float
    process_trees: int
    def __init__(self, total_ms: _Optional[float] = ..., find_pids_ms: _Optional[float] = ..., precheck_ms: _Optional[float] = ..., criu_dump_ms: _Optional[float] = ..., overlay_sink_ms: _Optional[float] = ..., stopped_ms: _Optional[float] = ..., kill_ms: _Optional[float] = ..., overlay_restore_ms: _Optional[float] = ..., criu_restore_ms: _Optional[float] = ..., process_trees: _Optional[int] = ...) -> None: ...

class CreateCheckpointResponse(_message.Message):
    __slots__ = ("checkpoint_id", "timings", "created_at", "has_process_image", "parent_checkpoint_id", "image_bytes", "clear_refs_failed", "process_trees")
    CHECKPOINT_ID_FIELD_NUMBER: _ClassVar[int]
    TIMINGS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    HAS_PROCESS_IMAGE_FIELD_NUMBER: _ClassVar[int]
    PARENT_CHECKPOINT_ID_FIELD_NUMBER: _ClassVar[int]
    IMAGE_BYTES_FIELD_NUMBER: _ClassVar[int]
    CLEAR_REFS_FAILED_FIELD_NUMBER: _ClassVar[int]
    PROCESS_TREES_FIELD_NUMBER: _ClassVar[int]
    checkpoint_id: str
    timings: Timings
    created_at: int
    has_process_image: bool
    parent_checkpoint_id: str
    image_bytes: int
    clear_refs_failed: int
    process_trees: int
    def __init__(self, checkpoint_id: _Optional[str] = ..., timings: _Optional[_Union[Timings, _Mapping]] = ..., created_at: _Optional[int] = ..., has_process_image: bool = ..., parent_checkpoint_id: _Optional[str] = ..., image_bytes: _Optional[int] = ..., clear_refs_failed: _Optional[int] = ..., process_trees: _Optional[int] = ...) -> None: ...

class RestoreCheckpointRequest(_message.Message):
    __slots__ = ("checkpoint_id",)
    CHECKPOINT_ID_FIELD_NUMBER: _ClassVar[int]
    checkpoint_id: str
    def __init__(self, checkpoint_id: _Optional[str] = ...) -> None: ...

class RestoreCheckpointResponse(_message.Message):
    __slots__ = ("success", "timings")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    TIMINGS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    timings: Timings
    def __init__(self, success: bool = ..., timings: _Optional[_Union[Timings, _Mapping]] = ...) -> None: ...

class ListCheckpointsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListCheckpointsResponse(_message.Message):
    __slots__ = ("checkpoints",)
    CHECKPOINTS_FIELD_NUMBER: _ClassVar[int]
    checkpoints: _containers.RepeatedCompositeFieldContainer[CheckpointInfo]
    def __init__(self, checkpoints: _Optional[_Iterable[_Union[CheckpointInfo, _Mapping]]] = ...) -> None: ...

class DeleteCheckpointRequest(_message.Message):
    __slots__ = ("checkpoint_id",)
    CHECKPOINT_ID_FIELD_NUMBER: _ClassVar[int]
    checkpoint_id: str
    def __init__(self, checkpoint_id: _Optional[str] = ...) -> None: ...

class DeleteCheckpointResponse(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class CheckpointInfo(_message.Message):
    __slots__ = ("checkpoint_id", "name", "created_at", "image_bytes", "has_process_image", "parent_checkpoint_id", "process_trees")
    CHECKPOINT_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    IMAGE_BYTES_FIELD_NUMBER: _ClassVar[int]
    HAS_PROCESS_IMAGE_FIELD_NUMBER: _ClassVar[int]
    PARENT_CHECKPOINT_ID_FIELD_NUMBER: _ClassVar[int]
    PROCESS_TREES_FIELD_NUMBER: _ClassVar[int]
    checkpoint_id: str
    name: str
    created_at: int
    image_bytes: int
    has_process_image: bool
    parent_checkpoint_id: str
    process_trees: int
    def __init__(self, checkpoint_id: _Optional[str] = ..., name: _Optional[str] = ..., created_at: _Optional[int] = ..., image_bytes: _Optional[int] = ..., has_process_image: bool = ..., parent_checkpoint_id: _Optional[str] = ..., process_trees: _Optional[int] = ...) -> None: ...
